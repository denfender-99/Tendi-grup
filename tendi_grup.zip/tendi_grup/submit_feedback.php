<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = htmlspecialchars($_POST['nama']);
    $email = htmlspecialchars($_POST['email']);
    $pesan = htmlspecialchars($_POST['pesan']);

    // Simpan atau proses masukan (misalnya kirim ke email atau simpan ke database)
    echo "Terima kasih, $nama. Masukan Anda telah diterima.";
}
?>
